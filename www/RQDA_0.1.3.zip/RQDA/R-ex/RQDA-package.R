### Name: RQDA-package
### Title: Qualitative data analysis
### Aliases: RQDA-package RQDA
### Keywords: package

### ** Examples

## Not run: 
##D library(RQDA)
##D RQDA()
## End(Not run)



