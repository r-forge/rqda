### Name: RQDA-package
### Title: Qualitative data analysis
### Aliases: RQDA-package RQDA
### Keywords: package

### ** Examples

## not run
#library(RQDA)
#RQDA()
##



